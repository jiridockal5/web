const e=!0,r=!1;export{e as prerender,r as ssr};
