import{E as a}from"../../chunks/vendor.js";import"clsx";export{a as default};
