import{E as m}from"../chunks/sc458cce.js";export{m as component};
