import{I as o,H as r}from"../chunks/sc458cce.js";export{o as load_css,r as start};
