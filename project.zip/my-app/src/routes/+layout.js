// Enable prerendering for all pages (static site generation)
export const prerender = true;

// Disable SSR for fully static site
export const ssr = false;
